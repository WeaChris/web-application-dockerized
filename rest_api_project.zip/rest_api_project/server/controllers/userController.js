const mysql = require('mysql');


//create connection with mysql
const pool = mysql.createPool({
    connectionLimit: 100,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cloudproject'
});


//VIEW HOME PAGE
exports.view = (req, res) => {
    //Connect
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        console.log('My sql connected...');
        //user the connection
        connection.query('SELECT * FROM citizen', (err, rows) => {
            connection.release();
            //ELENXOYME TO QUERY , KANOYME RENDER TO HOME KAI PERNAME TA ROWS APO TO QUERY
            if (!err) {
                res.render('home', { rows });
            } else {
                console.log(err);
            }
            console.log('The data from citizen table : \n', rows);
        });
    });

}

//SEARCH
exports.search = (req, res) => {
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        console.log('My sql connected...');
        //saving users input at search bar
        let seartchItem = req.body.search;

        connection.query('SELECT * FROM citizen WHERE AT LIKE ? OR name LIKE ? OR surname LIKE ? OR gender LIKE ? OR birth_date LIKE ? OR AFM LIKE ? OR AMKA LIKE ? OR adress LIKE ?', ['%' + seartchItem + '%', '%' + seartchItem + '%', '%' + seartchItem + '%', '%' + seartchItem + '%', '%' + seartchItem + '%', '%' + seartchItem + '%', '%' + seartchItem + '%', '%' + seartchItem + '%'], (err, rows) => {
            connection.release();
            //
            if (!err) {
                res.render('home', { rows });
            } else {
                console.log(err);
            }
            console.log('The data from citizen table : \n', rows);
        });
    });
};

exports.form = (req, res) => {
    res.render('adduser');
};


//ADD NEW USER
exports.adduser = (req, res) => {
    const { AT, name, surname, gender, birth_date, AFM, AMKA, adress, status } = req.body;

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        console.log('My sql connected...');
        //saving users input at search bar
        let seartchItem = req.body.search;

        connection.query('INSERT INTO citizen SET AT = ? ,name = ?, surname = ?, gender = ?, birth_date = ?, AFM = ? , AMKA = ?, adress = ?, status = ?', [AT, name, surname, gender, birth_date, AFM, AMKA, adress, status] , (err, rows) => {
            connection.release();
            //
            if (!err) {
                res.render('adduser', { rows });
            } else {
                console.log(err);
            }
            
        });
    });
};

