const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
//-----------------------ROUTES-------------------------



router.get('/home', userController.view);
router.post('/home', userController.search);
router.get('/adduser', userController.form);
router.post('/adduser', userController.adduser);

module.exports = router;