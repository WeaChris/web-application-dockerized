const routes = require('./server/routes/user');
const express = require('express');
const mysql = require('mysql');
const exphbs = require("express-handlebars");
const bodyParser =require("body-parser");

require('dotenv').config();

const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static('public'));

app.engine('hbs', exphbs({ extname: '.hbs' }));
app.set('view engine', 'hbs');

//create connection with mysql
const database = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cloudproject'
});
//Connect
database.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('My sql connected...');
});


app.use('/', routes);

app.listen(process.env.PORT || '8080', () => {
    console.log(`Server is running on port : 8080`);
});